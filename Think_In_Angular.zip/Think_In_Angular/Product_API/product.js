const express = require("express");
var cors = require('cors');

const app = express();
const bodyparser = require("body-parser");

const port = process.env.PORT || 9000;
app.use(cors());
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));

app.listen(port, () => {
  console.log(`running at port ${port}`);
});

const products=[
    {category: "Sporting Goods", price: "49.99", stocked: true, name: "Football"},
  {category: "Sporting Goods", price: "9.99", stocked: true, name: "Baseball"},
  {category: "Sporting Goods", price: "29.99", stocked: false, name: "Basketball"},
  {category: "Electronics", price: "99.99", stocked: true, name: "iPod Touch"},
  {category: "Electronics", price: "399.99", stocked: false, name: "iPhone 5"},
  {category: "Electronics", price: "199.99", stocked: true, name: "Nexus 7"}
];



app.get("/products",(req,res)=>{

    res.status(200).json(products);

});



      
    
  