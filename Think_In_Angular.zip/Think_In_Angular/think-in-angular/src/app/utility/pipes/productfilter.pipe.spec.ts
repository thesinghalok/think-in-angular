import { ProductfilterPipe } from './productfilter.pipe';

describe('ProductfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
