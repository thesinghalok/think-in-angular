import { Pipe, PipeTransform } from '@angular/core';
import { ProductModel } from 'src/app/models/product.model';

@Pipe({
  name: 'productfilter'
})
export class ProductfilterPipe implements PipeTransform {

  transform(products:Array<ProductModel>,category:string, searchText:string, showStockedProduct:boolean): Array<ProductModel> {
    if(!products || !searchText)
    {
      console.log(searchText);
    return products.filter(product=>(product.category==category));
    }

  if(showStockedProduct == true){
    console.log(showStockedProduct);
    return products.filter(product => product.category==category && (product.stocked==true && product.name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1));
  }
  else{
    return products.filter(product => product.category==category && (product.name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1));
  }
}

}
