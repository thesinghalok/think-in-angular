import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductfilterPipe } from './pipes/productfilter.pipe';



@NgModule({
  declarations: [
    ProductfilterPipe
  ],
  imports: [
    CommonModule
  ],
  exports:[ProductfilterPipe]
})
export class UtilityModule { }
