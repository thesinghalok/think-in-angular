import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'heading-component',
  templateUrl: './heading.component.html',
  styleUrls: ['./heading.component.css']
})
export class HeadingComponent implements OnInit {

  @Input()
  heading:string="";
  constructor() { }

  ngOnInit(): void {
  }

}
