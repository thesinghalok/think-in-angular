import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LabelComponent } from './component/label/label.component';
import { HeadingComponent } from './component/heading/heading.component';



@NgModule({
  declarations: [
    LabelComponent,
    HeadingComponent
  ],
  exports: [LabelComponent,HeadingComponent],
  imports: [
    CommonModule
  ]
})
export class WidgetsModule { }
