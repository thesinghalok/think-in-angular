export class ProductModel
{
    constructor(public category:string, public price:number,public stocked:boolean,public name:string ){
    
    }

}