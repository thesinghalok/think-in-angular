export class ProductSearch
{
constructor(public searchText:string,public stockChecked:boolean){}
}