import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  httpClient:HttpClient;
  constructor(httpClient:HttpClient,@Inject("serviceAddress") public serviceAddress:string){

    this.httpClient=httpClient;
  }

  getProductList()
  {
    return this.httpClient.get(`${this.serviceAddress}/products`);
  }
}
