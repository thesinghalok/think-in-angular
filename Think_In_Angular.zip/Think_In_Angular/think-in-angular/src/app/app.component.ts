import { Component, ViewChild } from '@angular/core';
import { ProductSearch } from './models/productSearch.model';
import { ListComponent } from './products/component/list/list.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  result: ProductSearch = <ProductSearch>{};
  title = 'think-in-angular';
  @ViewChild(ListComponent)
  computationChild!: ListComponent;
  onResultComputedHandler(data: ProductSearch) {
    this.computationChild.searchParam = data;
  }
}




