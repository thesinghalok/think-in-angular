import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchComponent } from './component/search/search.component';
import { FormsModule } from '@angular/forms';
import { WidgetsModule } from '../widgets/widgets.module';
import { ListComponent } from './component/list/list.component';
import { UtilityModule } from '../utility/utility.module';
import { ProductfilterPipe } from '../utility/pipes/productfilter.pipe';



@NgModule({
  declarations: [
    SearchComponent,
    ListComponent
  ],
  imports: [
    CommonModule,
    WidgetsModule,
    FormsModule,
    UtilityModule
  ],
  exports:[SearchComponent,ListComponent]
})
export class ProductsModule { }
