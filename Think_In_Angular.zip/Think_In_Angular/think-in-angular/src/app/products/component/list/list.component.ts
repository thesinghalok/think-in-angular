import { Component, Input, OnInit } from '@angular/core';
import { Router, TitleStrategy } from '@angular/router';
import { ProductModel } from 'src/app/models/product.model';
import { ProductSearch } from 'src/app/models/productSearch.model';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'product-list-component',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  @Input()
  searchParam:ProductSearch=<ProductSearch>{};

 
  productList: Array<ProductModel>=[];
  productCategory:Array<string>=[];
  constructor(public router:Router,public searchService:SearchService) { }

  ngOnInit(): void {
 
    this.searchService.getProductList().subscribe((result:any)=>{
      this.productList=result;
      if(this.productList.length>0)
      {
        this.productCategory=[...new Set(this.productList.map(item => item.category))];
      }
    })
  }

 

}
