import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ProductSearch } from 'src/app/models/productSearch.model';

@Component({
  selector: 'product-search-component',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchText:string="";
  stockChecked:boolean=false;


  @Output()
  searchParam = new EventEmitter<ProductSearch>();
  constructor() { }

  ngOnInit(): void {
  }
  onSearch(event: any) {
    this.searchParam.emit(new ProductSearch(this.searchText,this.stockChecked));
  }

  onStockChecked(event:any)
{
  this.searchParam.emit(new ProductSearch(this.searchText.toString(),this.stockChecked.valueOf()));
}
}
